
IMPORTANT:

If you plan to modify any of these templates, please make a copy
into the user template directory /etc/cmon/templates/, as 
any modifications here (/usr/share/cmon/templates) will get lost
during package updates.

This custom template directly usage is available from
clustercontrol-controller >= 1.6.2.

