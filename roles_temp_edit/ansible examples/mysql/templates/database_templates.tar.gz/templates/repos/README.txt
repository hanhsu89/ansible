Both the yum (.repo) and apt (.list) templates supports
the following subtitution variables:

 - @DISTRO@ : the distributor name (eg.: debian/ubuntu)
    APT: equivalent to lsb_release -i -s | tr \"[A-Z]\" \"[a-z]\",
    YUM: redhat, centos, fedora, amazon, oracle, opensuse
 - @CODENAME@ : the distribution code name (eg.: sid/wheezy/lucid/precise)
    APT: equivalent to lsb_release -c -s,
    YUM: 5,6,7 [the RedHat/CentOS version number]
 - @DBVERSION@ : the selected DB version
    for example: "5.5" or "10.0" for MariaDB vendor


Filenames:
- NAME.asc  -> (repo signing key) will be added to apt/yum trust store
- NAME.perf -> /etc/apt/preferences.d
- NAME.list -> /etc/apt/sources.list.d

NOTE:
 clustercontrol-controller tries to find and use the repository templates
 for software installation and/or local repository mirror
 creation in the following order:
  - CLUSTER_TYPE.[repo|list]
  - DBVENDOR.[repo|list]

